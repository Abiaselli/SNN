# snn_lut_cpp (CPU baseline, byte-level)

Self-contained C++17 implementation of a byte-level LUT-based "spiking transformer"-style model.
No third-party dependencies; builds with gcc/clang via CMake.

## Build
```bash
mkdir -p build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build . -j
```

## Train
```bash
./snn_lut train --ckpt-dir runs/run1 --data file1.bin --data file2.png --steps 50000 --save-every 5000 --eval-every 2000 --keep-last 5
```

Artifacts:
- `runs/run1/loss.csv` : step, lr, eval_nll
- `runs/run1/ckpt_step_000000005000.bin` (rotated)
- `runs/run1/best.bin` (best eval_nll observed)
- `runs/run1/latest.bin` (final checkpoint)

Resume:
```bash
./snn_lut train --ckpt-dir runs/run1 --resume runs/run1/latest.bin --steps 50000
```

## Sample
```bash
./snn_lut sample --ckpt runs/run1/best.bin --prompt "hello " --len 200 --temp 0.4 --out out.bin
```

## Notes
- This is a faithful CPU baseline intended for correctness + checkpointing.
- CUDA acceleration and sparse-LUT backends can be added later behind the same interfaces.
