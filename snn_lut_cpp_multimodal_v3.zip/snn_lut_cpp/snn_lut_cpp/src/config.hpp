#pragma once
#include <cstdint>
#include <cmath>

struct HyperParams {
  // Data
  int vocab_size = 256;      // bytes
  int context    = 32;

  // Model
  int embedding_dim  = 32;
  int positional_dim = 4;
  int num_layers     = 6;
  int num_heads      = 4;

  // LUT
  int n_t = 16; // number of tables
  int n_c = 6;  // comparisons per table

  // Training
  int testing_length = 10000;
  float temp_train   = 1.0f;
  float temp_sample  = 0.4f;

  // checkpoint format version
  uint32_t ckpt_version = 1;

  // Dataset
  bool use_markers = false; // default off for parity with main.c

};

inline float learning_rate_schedule(uint64_t t) {
  const float a = 1.0f / std::sqrt(1.0f + (float)t);
  const float b = ((float)t / 4000.0f) / std::sqrt(4000.0f);
  return (a < b) ? a : b;
}
