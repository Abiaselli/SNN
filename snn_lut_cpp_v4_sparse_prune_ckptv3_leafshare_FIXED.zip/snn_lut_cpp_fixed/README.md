# snn_lut_cpp (CPU baseline, byte-level)

Self-contained C++17 implementation of a byte-level LUT-based "spiking transformer"-style model.
No third-party dependencies; builds with gcc/clang via CMake.

## Build

Recommended (clean, out-of-source build):
```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

If you see a CMake error like "The source directory ... does not match" or anything mentioning `CMakeCache.txt`, delete the `build/` folder and re-run the two commands above.


## Train
```bash
./snn_lut train --ckpt-dir runs/run1 --data file1.bin --data file2.png --steps 50000 --save-every 5000 --eval-every 2000 --keep-last 5
```

Artifacts:
- `runs/run1/loss.csv` : step, lr, eval_nll
- `runs/run1/ckpt_step_000000005000.bin` (rotated)
- `runs/run1/best.bin` (best eval_nll observed)
- `runs/run1/latest.bin` (final checkpoint)

Resume:
```bash
./snn_lut train --ckpt-dir runs/run1 --resume runs/run1/latest.bin --steps 50000
```

## Sample
```bash
./snn_lut sample --ckpt runs/run1/best.bin --prompt "hello " --len 200 --temp 0.4 --out out.bin
```

## Notes
- This is a faithful CPU baseline intended for correctness + checkpointing.
- CUDA acceleration and sparse-LUT backends can be added later behind the same interfaces.

### Dataset preprocessing

When adding a file via `--data`, the loader treats it as a sequence of bytes.  To help the
model distinguish between different modalities, each file is automatically wrapped
with a textual marker based on its extension.  For example, a file `foo.json` is loaded
as:

```
<JSON>    \ five bytes of ASCII prefix
...raw file bytes...
</JSON>   \ seven bytes of ASCII suffix
```

Likewise, `.txt`/`.text` files are wrapped with `<TXT>`/`</TXT>`, `.csv` with `<CSV>`/`</CSV>`,
`.parquet`/`.pq` with `<PARQUET>`/`</PARQUET>`, and unknown extensions with `<BIN>`/`</BIN>`.
These markers occupy only a handful of extra bytes but provide the model context about the
input type.  When training on text-only data, the effect is simply adding `<TXT>` at the
beginning and `</TXT>` at the end of the file.


### Modality markers (optional)

By default, files are loaded as raw bytes (matches the original `main.c`).
If you want per-file type markers like `<JSON>... </JSON>`, enable:

```bash
./snn_lut train ... --markers
```


## Checkpoint utilities

Show what's inside a checkpoint:

```bash
./snn_lut ckpt-info --ckpt runs/run2/best.bin
```

Checkpoint size control:
- Default: stores float tensors as FP16 on disk (`--ckpt-fp16`) to shrink checkpoints
- Force FP32 on disk: `--ckpt-fp32`

Note: checkpoint size is dominated by LUT tables, not by dataset history.
