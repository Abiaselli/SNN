#pragma once
#include "config.hpp"
#include "rng.hpp"
#include "lut.hpp"
#include <vector>
#include <cstring>
#include <cmath>
#include <algorithm>

inline void softmax_inplace(float* x, int n, float temp) {
  float mx = x[0];
  for (int i = 1; i < n; i++) mx = std::max(mx, x[i]);
  float sum = 0.0f;
  for (int i = 0; i < n; i++) { x[i] = std::exp((x[i]-mx)/temp); sum += x[i]; }
  float inv = 1.0f / (sum + 1e-20f);
  for (int i = 0; i < n; i++) x[i] *= inv;
}

inline int sample_from_probs(const float* p, int n, RNG& rng) {
  float coin = rng.uniform01();
  float cdf = 0.0f;
  for (int i = 0; i < n; i++) {
    cdf += p[i];
    if (coin < cdf) return i;
  }
  return n-1;
}

struct AttentionHead {
  HyperParams hp;
  LUT V; // total_n_c = n_c + n_c + positional_dim, y_dim = embedding_dim
  std::vector<float> positional; // [context][n_t][pos_dim]
  std::vector<LUTCache> V_cache; // [context]
  std::vector<LUTCache> PE_cache;// [context] (by relative position)

  void init(const HyperParams& hp_, RNG& rng) {
    hp = hp_;
    V.init(hp, rng, hp.n_c + hp.n_c + hp.positional_dim, hp.embedding_dim);

    positional.resize((size_t)hp.context * (size_t)hp.n_t * (size_t)hp.positional_dim);
    for (auto& v : positional) v = rng.uniform_signed(1.0f);

    V_cache.resize((size_t)hp.context);
    PE_cache.resize((size_t)hp.context);
    for (int i = 0; i < hp.context; i++) {
      V_cache[(size_t)i] = V.make_cache();
      PE_cache[(size_t)i] = V.make_cache();
    }
  }

  const float* pos_ptr(int rel_pos) const {
    return &positional[(size_t)rel_pos * (size_t)hp.n_t * (size_t)hp.positional_dim];
  }

  void forward(const float* x /*[context][emb]*/, float* y /*[context][emb]*/) {
    for (int pos = 0; pos < hp.context; pos++) {
      V.cache_index(&x[(size_t)pos * (size_t)hp.embedding_dim], V_cache[(size_t)pos]);
      V.cache_pe_index(pos_ptr(pos), PE_cache[(size_t)pos]);
    }

    for (int pos = 1; pos < hp.context; pos++) {
      float* y_pos = &y[(size_t)pos * (size_t)hp.embedding_dim];
      for (int pos1 = 0; pos1 < pos; pos1++) {
        const auto& cQ  = V_cache[(size_t)pos];
        const auto& cK  = V_cache[(size_t)pos1];
        const auto& cPE = PE_cache[(size_t)(pos - pos1)];

        for (int i = 0; i < hp.n_t; i++) {
          size_t base = concat_index(hp, cQ.j[(size_t)i], cK.j[(size_t)i], cPE.j[(size_t)i], hp.embedding_dim);
          auto& tab = V.S[(size_t)i];
          for (int k = 0; k < hp.embedding_dim; k++) y_pos[k] += tab[base + (size_t)k];
        }
      }
    }
  }

  void backward(float* x_grad, const float* y_grad, float lr) {
    std::vector<float> pos_grad(positional.size(), 0.0f);

    for (int pos = 1; pos < hp.context; pos++) {
      const float* yg = &y_grad[(size_t)pos * (size_t)hp.embedding_dim];

      for (int pos1 = 0; pos1 < pos; pos1++) {
        auto& cQ  = V_cache[(size_t)pos];
        auto& cK  = V_cache[(size_t)pos1];
        auto& cPE = PE_cache[(size_t)(pos - pos1)];

        float* xgQ = &x_grad[(size_t)pos  * (size_t)hp.embedding_dim];
        float* xgK = &x_grad[(size_t)pos1 * (size_t)hp.embedding_dim];

        for (int i = 0; i < hp.n_t; i++) {
          int jQ  = cQ.j[(size_t)i];
          int jK  = cK.j[(size_t)i];
          int jPE = cPE.j[(size_t)i];

          size_t j = concat_index(hp, jQ, jK, jPE, hp.embedding_dim);

          float uQ  = std::fabs(cQ.u_min[(size_t)i]);
          float uK  = std::fabs(cK.u_min[(size_t)i]);
          float uPE = std::fabs(cPE.u_min[(size_t)i]);

          if (uQ < uK) {
            int jQb = jQ ^ (1 << cQ.r_min[(size_t)i]);
            size_t jbar = concat_index(hp, jQb, jK, jPE, hp.embedding_dim);

            float gi = 0.0f;
            auto& tab = V.S[(size_t)i];
            for (int k = 0; k < hp.embedding_dim; k++) gi += yg[k] * (tab[jbar+(size_t)k] - tab[j+(size_t)k]);
            float v = gi * Up(cQ.u_min[(size_t)i]);

            int idx = i*hp.n_c + cQ.r_min[(size_t)i];
            xgQ[V.a[(size_t)idx]] += v;
            xgQ[V.b[(size_t)idx]] -= v;
          } else {
            int jKb = jK ^ (1 << cK.r_min[(size_t)i]);
            size_t jbar = concat_index(hp, jQ, jKb, jPE, hp.embedding_dim);

            float gi = 0.0f;
            auto& tab = V.S[(size_t)i];
            for (int k = 0; k < hp.embedding_dim; k++) gi += yg[k] * (tab[jbar+(size_t)k] - tab[j+(size_t)k]);
            float v = gi * Up(cK.u_min[(size_t)i]);

            int idx = i*hp.n_c + cK.r_min[(size_t)i];
            xgK[V.a[(size_t)idx]] += v;
            xgK[V.b[(size_t)idx]] -= v;
          }

          if (uPE < uQ && uPE < uK) {
            int jPEb = jPE ^ (1 << cPE.r_min[(size_t)i]);
            size_t jbarPE = concat_index(hp, jQ, jK, jPEb, hp.embedding_dim);

            float gi = 0.0f;
            auto& tab = V.S[(size_t)i];
            for (int k = 0; k < hp.embedding_dim; k++) gi += yg[k] * (tab[jbarPE+(size_t)k] - tab[j+(size_t)k]);
            float delta = gi * Up(cPE.u_min[(size_t)i]);

            int rel = pos - pos1;
            size_t off = (size_t)rel * (size_t)hp.n_t * (size_t)hp.positional_dim
                       + (size_t)i * (size_t)hp.positional_dim
                       + (size_t)cPE.r_min[(size_t)i];
            pos_grad[off] += delta;
          }

          auto& tab = V.S[(size_t)i];
          for (int k = 0; k < hp.embedding_dim; k++) tab[j+(size_t)k] -= lr * yg[k];
        }
      }
    }

    for (size_t i = 0; i < positional.size(); i++) positional[i] -= lr * pos_grad[i];
  }
};

struct Model {
  HyperParams hp;

  std::vector<float> token_embedder; // [vocab][emb]
  std::vector<float> z;              // [context][emb]
  std::vector<int32_t> tokens;       // [context+1]

  std::vector<LUT> ffn;
  std::vector<std::vector<LUTCache>> ffn_cache;

  std::vector<std::vector<AttentionHead>> heads;

  LUT unembed;
  std::vector<LUTCache> unembed_cache;

  std::vector<float> output; // [context][vocab]

  void init(const HyperParams& hp_, RNG& rng) {
    hp = hp_;

    token_embedder.resize((size_t)hp.vocab_size * (size_t)hp.embedding_dim);
    for (auto& v : token_embedder) v = rng.uniform_signed(1.0f);

    z.assign((size_t)hp.context * (size_t)hp.embedding_dim, 0.0f);
    tokens.assign((size_t)hp.context + 1, 0);

    ffn.resize((size_t)hp.num_layers);
    ffn_cache.resize((size_t)hp.num_layers);
    heads.resize((size_t)hp.num_layers);

    for (int l = 0; l < hp.num_layers; l++) {
      ffn[(size_t)l].init(hp, rng, hp.n_c, hp.embedding_dim);
      ffn_cache[(size_t)l].resize((size_t)hp.context);
      for (int pos = 0; pos < hp.context; pos++) ffn_cache[(size_t)l][(size_t)pos] = ffn[(size_t)l].make_cache();

      heads[(size_t)l].resize((size_t)hp.num_heads);
      for (int h = 0; h < hp.num_heads; h++) heads[(size_t)l][(size_t)h].init(hp, rng);
    }

    unembed.init(hp, rng, hp.n_c, hp.vocab_size);
    unembed_cache.resize((size_t)hp.context);
    for (int pos = 0; pos < hp.context; pos++) unembed_cache[(size_t)pos] = unembed.make_cache();

    output.assign((size_t)hp.context * (size_t)hp.vocab_size, 0.0f);
  }

  inline const float* emb_ptr(int token_id) const {
    return &token_embedder[(size_t)token_id * (size_t)hp.embedding_dim];
  }

  void load_snippet(const uint8_t* data, uint32_t start) {
    for (int pos = 0; pos < hp.context; pos++) {
      int t = (int)data[start + (uint32_t)pos];
      tokens[(size_t)pos] = t;
      std::memcpy(&z[(size_t)pos*(size_t)hp.embedding_dim], emb_ptr(t), (size_t)hp.embedding_dim*sizeof(float));
    }
    tokens[(size_t)hp.context] = (int)data[start + (uint32_t)hp.context];
  }

  void forward() {
    for (int l = 0; l < hp.num_layers; l++) {
      std::vector<float> x = z; // snapshot for attention reads
      for (int h = 0; h < hp.num_heads; h++) {
        heads[(size_t)l][(size_t)h].forward(x.data(), z.data()); // residual into z
      }

      for (int pos = 0; pos < hp.context; pos++) {
        float* zpos = &z[(size_t)pos*(size_t)hp.embedding_dim];
        ffn[(size_t)l].cache_index(zpos, ffn_cache[(size_t)l][(size_t)pos]);
        ffn[(size_t)l].forward(ffn_cache[(size_t)l][(size_t)pos], zpos);
      }
    }

    std::fill(output.begin(), output.end(), 0.0f);
    for (int pos = 0; pos < hp.context; pos++) {
      float* zpos = &z[(size_t)pos*(size_t)hp.embedding_dim];
      float* outp = &output[(size_t)pos*(size_t)hp.vocab_size];
      unembed.cache_index(zpos, unembed_cache[(size_t)pos]);
      unembed.forward(unembed_cache[(size_t)pos], outp);
    }
  }

  void backward(float lr) {
    std::vector<float> x_grad((size_t)hp.context*(size_t)hp.embedding_dim, 0.0f);
    std::vector<float> y_grad((size_t)hp.context*(size_t)hp.embedding_dim, 0.0f);

    for (int pos = 0; pos < hp.context; pos++) {
      float* xg = &x_grad[(size_t)pos*(size_t)hp.embedding_dim];
      float* og = &output[(size_t)pos*(size_t)hp.vocab_size]; // output holds grad after softmax-xent
      unembed.backward(unembed_cache[(size_t)pos], xg, og, lr);
    }

    for (int l = hp.num_layers - 1; l >= 0; l--) {
      y_grad = x_grad;
      for (int pos = 0; pos < hp.context; pos++) {
        float* xg = &x_grad[(size_t)pos*(size_t)hp.embedding_dim];
        float* yg = &y_grad[(size_t)pos*(size_t)hp.embedding_dim];
        ffn[(size_t)l].backward(ffn_cache[(size_t)l][(size_t)pos], xg, yg, lr);
      }

      y_grad = x_grad;
      for (int h = 0; h < hp.num_heads; h++) {
        heads[(size_t)l][(size_t)h].backward(x_grad.data(), y_grad.data(), lr);
      }
    }
  }

  void training_step(float lr) {
    forward();
    for (int pos = 0; pos < hp.context; pos++) {
      float* outp = &output[(size_t)pos*(size_t)hp.vocab_size];
      softmax_inplace(outp, hp.vocab_size, hp.temp_train);
      outp[(size_t)tokens[(size_t)pos + 1]] -= 1.0f;
    }
    backward(lr);
  }

  int infer_next(RNG& rng, float temp_sample) {
    forward();
    float* outp = &output[(size_t)(hp.context - 1) * (size_t)hp.vocab_size];
    softmax_inplace(outp, hp.vocab_size, temp_sample);
    return sample_from_probs(outp, hp.vocab_size, rng);
  }
};
