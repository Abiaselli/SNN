#pragma once
#include <cstdint>

// Simple xorshift64* RNG (fast, deterministic, easy to serialize)
struct RNG {
  uint64_t s = 0x9E3779B97F4A7C15ull;

  explicit RNG(uint64_t seed=0xC0FFEEull) : s(seed ? seed : 0xC0FFEEull) {}

  uint64_t next_u64() {
    uint64_t x = s;
    x ^= x >> 12;
    x ^= x << 25;
    x ^= x >> 27;
    s = x;
    return x * 2685821657736338717ull;
  }

  uint32_t next_u32() { return (uint32_t)(next_u64() >> 32); }

  int uniform_int(int lo, int hi_inclusive) {
    uint32_t r = next_u32();
    uint32_t span = (uint32_t)(hi_inclusive - lo + 1);
    return lo + (int)(r % span);
  }

  float uniform01() {
    return (float)((next_u32() >> 8) & 0x00FFFFFF) / (float)0x01000000;
  }

  float uniform_signed(float scale) {
    return (uniform01() - 0.5f) * 2.0f * scale;
  }
};
