#include "config.hpp"
#include "rng.hpp"
#include "dataset.hpp"
#include "model.hpp"
#include "checkpoint.hpp"
#include "io.hpp"
#include "util.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <cmath>

static std::string get_arg(int& i, int argc, char** argv) {
  if (i+1 >= argc) throw std::runtime_error(std::string("Missing value for ") + argv[i]);
  return argv[++i];
}

static double eval_nll(Model& model, const MultiDataset& data, int per_file_samples = 200) {
  double total = 0.0;
  uint64_t count = 0;
  for (auto& f : data.files) {
    int n = std::min((int)f.val_idx.size(), per_file_samples);
    for (int i = 0; i < n; i++) {
      uint32_t idx = f.val_idx[(size_t)i];
      model.load_snippet(f.data.data(), idx);
      model.forward();
      float* outp = &model.output[(size_t)(model.hp.context-1) * (size_t)model.hp.vocab_size];
      softmax_inplace(outp, model.hp.vocab_size, 1.0f);
      int target = model.tokens[(size_t)model.hp.context];
      float p = outp[(size_t)target];
      total += -std::log((double)std::max(p, 1e-20f));
      count++;
    }
  }
  return total / (double)std::max<uint64_t>(1, count);
}

int main(int argc, char** argv) {
  try {
    if (argc < 2) {
      std::cerr << "Usage:\n"
                << "  snn_lut train  --data file1 --data file2 ... --ckpt-dir runs/run1 [--resume ckpt.bin] [--steps N]\n"
                << "               [--save-every K] [--eval-every E] [--log-every L] [--keep-last M] [--seed S]\n"
                << "               [--context C --emb D --layers L --heads H --nt NT --nc NC]\n"
                << "  snn_lut sample --ckpt ckpt.bin --prompt \"...\" --len N [--temp T] [--out out.bin]\n"
                << "  snn_lut eval   --ckpt ckpt.bin\n";
      return 1;
    }

    std::string cmd = argv[1];
    HyperParams hp;
    uint64_t seed = 0xC0FFEEull;
    uint64_t steps = 1000;
    uint64_t save_every = 1000;
    uint64_t eval_every = 2000;
    uint64_t log_every  = 200;
    int keep_last = 5;

    std::string ckpt_dir;
    std::string resume_ckpt;
    std::string ckpt_path;

    std::vector<std::string> data_files;

    std::string prompt;
    int sample_len = 200;
    float temp = hp.temp_sample;
    std::string sample_out;

    for (int i = 2; i < argc; i++) {
      std::string a = argv[i];
      if (a == "--data") data_files.push_back(get_arg(i, argc, argv));
      else if (a == "--ckpt-dir") ckpt_dir = get_arg(i, argc, argv);
      else if (a == "--ckpt") ckpt_path = get_arg(i, argc, argv);
      else if (a == "--resume") resume_ckpt = get_arg(i, argc, argv);
      else if (a == "--steps") steps = std::stoull(get_arg(i, argc, argv));
      else if (a == "--save-every") save_every = std::stoull(get_arg(i, argc, argv));
      else if (a == "--eval-every") eval_every = std::stoull(get_arg(i, argc, argv));
      else if (a == "--log-every") log_every = std::stoull(get_arg(i, argc, argv));
      else if (a == "--keep-last") keep_last = std::stoi(get_arg(i, argc, argv));
      else if (a == "--seed") seed = std::stoull(get_arg(i, argc, argv));
      else if (a == "--prompt") prompt = get_arg(i, argc, argv);
      else if (a == "--len") sample_len = std::stoi(get_arg(i, argc, argv));
      else if (a == "--temp") temp = std::stof(get_arg(i, argc, argv));
      else if (a == "--out") sample_out = get_arg(i, argc, argv);

      else if (a == "--context") hp.context = std::stoi(get_arg(i, argc, argv));
      else if (a == "--emb") hp.embedding_dim = std::stoi(get_arg(i, argc, argv));
      else if (a == "--layers") hp.num_layers = std::stoi(get_arg(i, argc, argv));
      else if (a == "--heads") hp.num_heads = std::stoi(get_arg(i, argc, argv));
      else if (a == "--nt") hp.n_t = std::stoi(get_arg(i, argc, argv));
      else if (a == "--nc") hp.n_c = std::stoi(get_arg(i, argc, argv));
      else if (a == "--test") hp.testing_length = std::stoi(get_arg(i, argc, argv));
      else throw std::runtime_error("Unknown arg: " + a);
    }

    RNG rng(seed);
    MultiDataset data; data.hp = hp;
    Model model;
    uint64_t step0 = 0;

    if (cmd == "train") {
      if (ckpt_dir.empty()) throw std::runtime_error("train requires --ckpt-dir runs/runX");
      ensure_dir(ckpt_dir);
      const std::string loss_csv = (std::filesystem::path(ckpt_dir) / "loss.csv").string();

      if (!resume_ckpt.empty()) {
        // Resume: load model, dataset and RNG state from checkpoint
        Checkpoint::load(resume_ckpt, hp, step0, rng, data, model);
        std::cerr << "Resumed from " << resume_ckpt << " at step=" << step0 << "\n";
        // If additional data files are provided, append them to the existing dataset. This allows
        // continued training on new sources without discarding the original train/val split.
        for (auto& p : data_files) {
          try {
            data.add_file(p, rng);
            std::cerr << "Loaded additional dataset: " << p << "\n";
          } catch (const std::exception& e) {
            std::cerr << "Warning: failed to load additional dataset '" << p << "': " << e.what() << "\n";
          }
        }
      } else {
        // Fresh run: require at least one data file
        if (data_files.empty()) throw std::runtime_error("train requires --data ...");
        for (auto& p : data_files) data.add_file(p, rng);
        model.init(hp, rng);
        step0 = 0;
        // Start a new loss CSV with header
        append_line(loss_csv, "step,train_lr,eval_nll");
      }

      double best_nll = 1e100;
      uint64_t best_step = 0;

      for (uint64_t t = 0; t < steps; t++) {
        uint64_t step = step0 + t;
        float lr = learning_rate_schedule(step);

        int fid = data.pick_file(rng);
        uint32_t idx = data.random_train_index(fid, rng);
        model.load_snippet(data.files[(size_t)fid].data.data(), idx);
        model.training_step(lr);

        if (log_every && (t % log_every) == 0) {
          std::cerr << "\rstep=" << step << " lr=" << std::fixed << std::setprecision(6) << lr << "   " << std::flush;
        }

        if (eval_every && (t % eval_every) == 0 && t > 0) {
          double nll = eval_nll(model, data, 100);
          append_line(loss_csv, std::to_string(step) + "," + std::to_string(lr) + "," + std::to_string(nll));
          std::cerr << "\n eval_nll=" << nll << "\n";

          if (nll < best_nll) {
            best_nll = nll;
            best_step = step;
            std::string best_path = (std::filesystem::path(ckpt_dir) / "best.bin").string();
            Checkpoint::save(best_path, hp, step, rng, data, model);
            std::cerr << "  saved best -> " << best_path << " (step=" << best_step << ")\n";
          }
        }

        if (save_every && (t % save_every) == 0 && t > 0) {
          // rotated checkpoint
          std::ostringstream oss;
          oss << "ckpt_step_" << std::setw(12) << std::setfill('0') << step << ".bin";
          std::string out_path = (std::filesystem::path(ckpt_dir) / oss.str()).string();
          Checkpoint::save(out_path, hp, step, rng, data, model);
          prune_old_ckpts(ckpt_dir, "ckpt_step_", keep_last);
          std::cerr << "\nSaved checkpoint: " << out_path << "\n";
        }
      }

      uint64_t final_step = step0 + steps;
      std::string final_path = (std::filesystem::path(ckpt_dir) / "latest.bin").string();
      Checkpoint::save(final_path, hp, final_step, rng, data, model);
      std::cerr << "\nSaved latest checkpoint: " << final_path << " step=" << final_step << "\n";
      // Compute and report final evaluation NLL over the validation split
      double nll_final = eval_nll(model, data, 200);
      std::cerr << "Final eval_nll=" << nll_final << "\n";
      // Append final evaluation to loss CSV as well
      append_line(loss_csv, std::to_string(final_step) + "," + std::to_string(learning_rate_schedule(final_step)) + "," + std::to_string(nll_final));
      return 0;
    }

    if (cmd == "sample") {
      if (ckpt_path.empty()) throw std::runtime_error("sample requires --ckpt in.bin");
      HyperParams hp2;
      MultiDataset data2;
      Model model2;
      uint64_t step=0;
      RNG rng2(seed);
      Checkpoint::load(ckpt_path, hp2, step, rng2, data2, model2);

      if (prompt.empty()) prompt = "hello";
      std::vector<uint8_t> window((size_t)hp2.context, 0);
      for (int i = 0; i < hp2.context; i++) {
        window[(size_t)i] = (i < (int)prompt.size()) ? (uint8_t)prompt[(size_t)i] : (uint8_t)' ';
      }

      std::vector<uint8_t> out_bytes;
      out_bytes.reserve((size_t)sample_len);

      std::cout << prompt;

      for (int i = 0; i < sample_len; i++) {
        for (int pos = 0; pos < hp2.context; pos++) {
          int tok = (int)window[(size_t)pos];
          std::memcpy(&model2.z[(size_t)pos*(size_t)hp2.embedding_dim],
                      &model2.token_embedder[(size_t)tok*(size_t)hp2.embedding_dim],
                      (size_t)hp2.embedding_dim*sizeof(float));
        }

        int nxt = model2.infer_next(rng2, temp);
        uint8_t b = (uint8_t)nxt;
        out_bytes.push_back(b);

        std::cout << (char)b << std::flush;

        for (int j = 0; j < hp2.context-1; j++) window[(size_t)j] = window[(size_t)j+1];
        window[(size_t)hp2.context-1] = b;
      }
      std::cout << "\n";

      if (!sample_out.empty()) {
        write_all_bytes(sample_out, out_bytes);
        std::cerr << "Wrote sampled bytes to: " << sample_out << "\n";
      }
      return 0;
    }

    if (cmd == "eval") {
      if (ckpt_path.empty()) throw std::runtime_error("eval requires --ckpt in.bin");
      HyperParams hp2;
      MultiDataset data2;
      Model model2;
      uint64_t step=0;
      RNG rng2(seed);
      Checkpoint::load(ckpt_path, hp2, step, rng2, data2, model2);
      double nll = eval_nll(model2, data2, 200);
      std::cout << "eval_nll=" << nll << "\n";
      return 0;
    }

    throw std::runtime_error("Unknown command: " + cmd);

  } catch (const std::exception& e) {
    std::cerr << "\nError: " << e.what() << "\n";
    return 1;
  }
}
