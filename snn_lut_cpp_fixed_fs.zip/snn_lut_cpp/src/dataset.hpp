#pragma once
#include "config.hpp"
#include "rng.hpp"
#include "io.hpp"
#include <vector>
#include <string>
#include <stdexcept>
#include <cstdint>
#include <algorithm>

struct DatasetFile {
  std::string path;
  std::vector<uint8_t> data;      // raw bytes
  std::vector<uint8_t> reserved;  // 0/1 mask for training positions
  std::vector<uint32_t> val_idx;  // validation start indices
  uint32_t usable_len = 0;        // data_len - (context+1)
};

struct MultiDataset {
  std::vector<DatasetFile> files;
  HyperParams hp;

  void add_file(const std::string& path, RNG& rng) {
    DatasetFile df;
    df.path = path;
    df.data = read_all_bytes(path);
    if (df.data.size() < (size_t)(hp.context + 2)) {
      throw std::runtime_error("File too small for context+1: " + path);
    }
    df.usable_len = (uint32_t)(df.data.size() - (size_t)(hp.context + 1));
    df.reserved.assign(df.usable_len, 0);
    df.val_idx.resize((size_t)hp.testing_length);

    for (int i = 0; i < hp.testing_length; i++) {
      uint32_t idx = (uint32_t)rng.uniform_int(0, (int)df.usable_len - 1);
      df.val_idx[(size_t)i] = idx;
      int start = std::max(0, (int)idx - hp.context);
      int end   = std::min((int)df.usable_len - 1, (int)idx + hp.context);
      for (int p = start; p <= end; p++) df.reserved[(size_t)p] = 1;
    }
    files.push_back(std::move(df));
  }

  int pick_file(RNG& rng) const {
    uint64_t total = 0;
    for (auto& f : files) total += f.usable_len;
    uint64_t r = rng.next_u64() % (total ? total : 1);
    uint64_t acc = 0;
    for (int i = 0; i < (int)files.size(); i++) {
      acc += files[(size_t)i].usable_len;
      if (r < acc) return i;
    }
    return (int)files.size() - 1;
  }

  uint32_t random_train_index(int file_id, RNG& rng) const {
    auto& f = files[(size_t)file_id];
    while (true) {
      uint32_t idx = (uint32_t)rng.uniform_int(0, (int)f.usable_len - 1);
      if (f.reserved[(size_t)idx] == 0) return idx;
    }
  }
};
