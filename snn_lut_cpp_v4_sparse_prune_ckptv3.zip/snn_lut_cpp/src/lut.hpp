#pragma once
#include "config.hpp"
#include "rng.hpp"
#include <vector>
#include <unordered_map>
#include <cstdint>
#include <cmath>
#include <cstring>
#include <limits>
#include <algorithm>

inline int sgn(float x) { return (x > 0.0f) ? 1 : -1; } // 0 treated as negative
inline float Up(float u) {
  float a = 1.0f + std::fabs(u);
  return -0.5f * (float)sgn(u) / (a * a);
}

struct LUTCache {
  std::vector<int32_t> j;      // [n_t]
  std::vector<int32_t> r_min;  // [n_t]
  std::vector<float>   u_min;  // [n_t]
};

struct LUT {
  HyperParams hp;
  int total_n_c = 0;
  int y_dim     = 0;

  std::vector<int32_t> a;
  std::vector<int32_t> b;

struct Leaf {
  std::vector<float> w;     // [y_dim]
  uint32_t count = 0;
  float importance_ema = 0.0f;
};

// Sparse leaves per table: only allocate rows we actually touch.
// Key: leaf index j (0..2^total_n_c-1)
std::vector<std::unordered_map<uint32_t, Leaf>> S;

const float* leaf_const(int table, uint32_t j) const {
  const auto& mp = S[(size_t)table];
  auto it = mp.find(j);
  if (it == mp.end()) return nullptr;
  return it->second.w.data();
}

Leaf& leaf_mut(int table, uint32_t j) {
  auto& mp = S[(size_t)table];
  auto it = mp.find(j);
  if (it == mp.end()) {
    Leaf lf;
    lf.w.assign((size_t)y_dim, 0.0f);
    auto res = mp.emplace(j, std::move(lf));
    return res.first->second;
  }
  return it->second;
}

// Simple pruning: drop leaves that are rarely used and have low impact.
void prune(uint32_t min_count, float min_importance) {
  for (auto& mp : S) {
    for (auto it = mp.begin(); it != mp.end(); ) {
      const Leaf& lf = it->second;
      if (lf.count < min_count && lf.importance_ema < min_importance) it = mp.erase(it);
      else ++it;
    }
  }
}


  void init(const HyperParams& hp_, RNG& rng, int total_n_c_, int y_dim_) {
    hp = hp_;
    total_n_c = total_n_c_;
    y_dim = y_dim_;

    a.resize((size_t)hp.n_t * (size_t)hp.n_c);
    b.resize((size_t)hp.n_t * (size_t)hp.n_c);

    for (int i = 0; i < hp.n_t; i++) {
      for (int r = 0; r < hp.n_c; r++) {
        int idx = i*hp.n_c + r;
        int aa = rng.uniform_int(0, hp.embedding_dim - 1);
        int bb;
        do { bb = rng.uniform_int(0, hp.embedding_dim - 1); } while (bb == aa);
        a[(size_t)idx] = aa;
        b[(size_t)idx] = bb;
      }
    }

    S.clear();
S.resize((size_t)hp.n_t);
// NOTE: We do NOT allocate dense tables here. Leaves are allocated on demand.
}

  LUTCache make_cache() const {
    LUTCache c;
    c.j.assign((size_t)hp.n_t, 0);
    c.r_min.assign((size_t)hp.n_t, 0);
    c.u_min.assign((size_t)hp.n_t, 0.0f);
    return c;
  }

  void cache_index(const float* x, LUTCache& cache) const {
    for (int i = 0; i < hp.n_t; i++) {
      int ji = 0;
      float umin = std::numeric_limits<float>::infinity();
      int rmin = 0;
      for (int r = 0; r < hp.n_c; r++) {
        int idx = i*hp.n_c + r;
        float u = x[a[(size_t)idx]] - x[b[(size_t)idx]];
        if (u > 0.0f) ji |= (1 << r);
        if (std::fabs(u) < std::fabs(umin)) { umin = u; rmin = r; }
      }
      cache.j[(size_t)i] = ji;
      cache.r_min[(size_t)i] = rmin;
      cache.u_min[(size_t)i] = umin;
    }
  }

  void cache_pe_index(const float* u /*[n_t*pos_dim]*/, LUTCache& cache) const {
    for (int i = 0; i < hp.n_t; i++) {
      int ji = 0;
      float umin = std::numeric_limits<float>::infinity();
      int rmin = 0;
      for (int r = 0; r < hp.positional_dim; r++) {
        float val = u[i*hp.positional_dim + r];
        if (val > 0.0f) ji |= (1 << r);
        if (std::fabs(val) < std::fabs(umin)) { umin = val; rmin = r; }
      }
      cache.j[(size_t)i] = ji;
      cache.r_min[(size_t)i] = rmin;
      cache.u_min[(size_t)i] = umin;
    }
  }

  void forward(const LUTCache& cache, float* y /*[y_dim]*/) const {
  for (int i = 0; i < hp.n_t; i++) {
    uint32_t j = (uint32_t)cache.j[(size_t)i];
    const float* w = leaf_const(i, j);
    if (!w) continue;
    for (int k = 0; k < y_dim; k++) y[k] += w[(size_t)k];
  }
}


  void backward(const LUTCache& cache,
              float* x_grad /*[embedding_dim]*/,
              const float* y_grad /*[y_dim]*/,
              float lr) {
  // Exponential moving average factor for importance tracking
  const float alpha = 0.01f;

  for (int i = 0; i < hp.n_t; i++) {
    int j = cache.j[(size_t)i];
    int rmin = cache.r_min[(size_t)i];
    float umin = cache.u_min[(size_t)i];

    int jbar = (j ^ (1 << rmin));

    const float* w  = leaf_const(i, (uint32_t)j);
    const float* wb = leaf_const(i, (uint32_t)jbar);

    // If missing, treat as zero vector.
    float gi = 0.0f;
    for (int k = 0; k < y_dim; k++) {
      float wk  = w  ? w[(size_t)k]  : 0.0f;
      float wbk = wb ? wb[(size_t)k] : 0.0f;
      gi += y_grad[(size_t)k] * (wbk - wk);
    }
    float v = gi * Up(umin);

    int idx = i*hp.n_c + rmin;
    x_grad[a[(size_t)idx]] += v;
    x_grad[b[(size_t)idx]] -= v;

    // SGD update only on the active leaf j (allocate on demand).
    Leaf& lf = leaf_mut(i, (uint32_t)j);
    for (int k = 0; k < y_dim; k++) lf.w[(size_t)k] -= lr * y_grad[(size_t)k];

    lf.count += 1;
    float imp = std::fabs(gi);
    lf.importance_ema = (1.0f - alpha) * lf.importance_ema + alpha * imp;
  }
}
};



inline uint32_t concat_leaf(const HyperParams& hp, int Q, int K, int PE) {
  int shiftQ = hp.n_c + hp.positional_dim;
  int shiftK = hp.positional_dim;
  uint32_t j = ((uint32_t)Q << shiftQ) | ((uint32_t)K << shiftK) | (uint32_t)PE;
  return j;
}

inline size_t concat_index(const HyperParams& hp, int Q, int K, int PE, int y_dim) {
  uint32_t j = concat_leaf(hp, Q, K, PE);
  return (size_t)j * (size_t)y_dim;
}
