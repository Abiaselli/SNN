#include <iostream>
#include <string>
#include <vector>
#include <cstring>
#include <algorithm>

#include "config.hpp"
#include "dataset.hpp"
#include "model.hpp"
#include "checkpoint.hpp"
#include "rng.hpp"

static std::string get_arg(int& i, int argc, char** argv) {
  if (i + 1 >= argc) throw std::runtime_error(std::string("Missing value after ") + argv[i]);
  i++;
  return std::string(argv[i]);
}

static void usage() {
  std::cerr
    << "Usage:\n"
    << "  snn_chat --ckpt ckpt.bin [--temp T] [--max-gen N] [--system S] [--seed N]\n"
    << "\n"
    << "Commands inside chat:\n"
    << "  /exit, /quit        exit\n"
    << "  /temp <float>       set temperature\n"
    << "  /maxgen <int>       set maximum generation bytes per turn\n"
    << "  /reset              clear rolling context\n";
}

int main(int argc, char** argv) {
  try {
    std::string ckpt_path;
    float temp = 0.7f;
    int max_gen = 256;
    std::string system_prompt;
    uint64_t seed = 123;

    for (int i = 1; i < argc; i++) {
      std::string a = argv[i];
      if (a == "--ckpt") ckpt_path = get_arg(i, argc, argv);
      else if (a == "--temp") temp = std::stof(get_arg(i, argc, argv));
      else if (a == "--max-gen") max_gen = std::stoi(get_arg(i, argc, argv));
      else if (a == "--system") system_prompt = get_arg(i, argc, argv);
      else if (a == "--seed") seed = (uint64_t)std::stoull(get_arg(i, argc, argv));
      else if (a == "-h" || a == "--help") { usage(); return 0; }
      else throw std::runtime_error("Unknown argument: " + a);
    }

    if (ckpt_path.empty()) {
      usage();
      throw std::runtime_error("Missing required --ckpt ckpt.bin");
    }

    HyperParams hp;
    MultiDataset data;
    Model model;
    uint64_t step = 0;
    RNG rng(seed);

    Checkpoint::load(ckpt_path, hp, step, rng, data, model);

    // Rolling context window (byte-level)
    std::vector<uint8_t> window((size_t)hp.context, (uint8_t)'\n');

    auto push_byte = [&](uint8_t c) {
      for (int j = 0; j < hp.context - 1; j++) window[(size_t)j] = window[(size_t)j + 1];
      window[(size_t)hp.context - 1] = c;
    };
    auto push_str = [&](const std::string& s) {
      for (unsigned char c : s) push_byte((uint8_t)c);
    };

    if (!system_prompt.empty()) {
      push_str(system_prompt);
      push_str("\n");
    }

    std::cout << "Loaded " << ckpt_path << " (step=" << step << "). Type /exit to quit.\n";
    std::cout << "Commands: /exit  /temp <float>  /maxgen <int>  /reset\n";

    std::string line;
    while (true) {
      std::cout << "\n> " << std::flush;
      if (!std::getline(std::cin, line)) break;

      if (line == "/exit" || line == "/quit") break;

      if (line == "/reset") {
        std::fill(window.begin(), window.end(), (uint8_t)'\n');
        if (!system_prompt.empty()) { push_str(system_prompt); push_str("\n"); }
        std::cout << "(context reset)\n";
        continue;
      }

      if (line.rfind("/temp ", 0) == 0) {
        try { temp = std::stof(line.substr(6)); std::cout << "(temp=" << temp << ")\n"; }
        catch(...) { std::cout << "(bad temp)\n"; }
        continue;
      }

      if (line.rfind("/maxgen ", 0) == 0) {
        try { max_gen = std::stoi(line.substr(8)); std::cout << "(max_gen=" << max_gen << ")\n"; }
        catch(...) { std::cout << "(bad maxgen)\n"; }
        continue;
      }

      // Add user message to context with simple role tags
      push_str("User: ");
      push_str(line);
      push_str("\nAssistant: ");

      std::cout << "Assistant: " << std::flush;

      for (int t = 0; t < max_gen; t++) {
        // Fill model.z from the rolling window (byte -> embedding row)
        for (int pos = 0; pos < hp.context; pos++) {
          int tok = (int)window[(size_t)pos];
          std::memcpy(&model.z[(size_t)pos * (size_t)hp.embedding_dim],
                      &model.token_embedder[(size_t)tok * (size_t)hp.embedding_dim],
                      (size_t)hp.embedding_dim * sizeof(float));
        }

        int nxt = model.infer_next(rng, temp);
        unsigned char c = (unsigned char)nxt;

        // End the assistant turn on newline (after a little content)
        if (c == '\n' && t > 8) { std::cout << "\n"; push_str("\n"); break; }

        // Print safe ASCII for terminal; feed raw byte back into context regardless
        if (c==9 || c==10 || c==13 || (c>=32 && c<=126)) std::cout << (char)c << std::flush;
        else std::cout << '.' << std::flush;

        push_byte((uint8_t)c);
      }
    }

    std::cout << "\nBye.\n";
    return 0;

  } catch (const std::exception& e) {
    std::cerr << "Error: " << e.what() << "\n";
    return 1;
  }
}
