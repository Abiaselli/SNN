#pragma once
#include "config.hpp"
#include "rng.hpp"
#include <vector>
#include <cstdint>
#include <cmath>
#include <cstring>
#include <limits>
#include <algorithm>

inline int sgn(float x) { return (x > 0.0f) ? 1 : -1; } // 0 treated as negative
inline float Up(float u) {
  float a = 1.0f + std::fabs(u);
  return -0.5f * (float)sgn(u) / (a * a);
}

struct LUTCache {
  std::vector<int32_t> j;      // [n_t]
  std::vector<int32_t> r_min;  // [n_t]
  std::vector<float>   u_min;  // [n_t]
};

struct LUT {
  HyperParams hp;
  int total_n_c = 0;
  int y_dim     = 0;

  std::vector<int32_t> a;
  std::vector<int32_t> b;

  std::vector<std::vector<float>> S;

  void init(const HyperParams& hp_, RNG& rng, int total_n_c_, int y_dim_) {
    hp = hp_;
    total_n_c = total_n_c_;
    y_dim = y_dim_;

    a.resize((size_t)hp.n_t * (size_t)hp.n_c);
    b.resize((size_t)hp.n_t * (size_t)hp.n_c);

    for (int i = 0; i < hp.n_t; i++) {
      for (int r = 0; r < hp.n_c; r++) {
        int idx = i*hp.n_c + r;
        int aa = rng.uniform_int(0, hp.embedding_dim - 1);
        int bb;
        do { bb = rng.uniform_int(0, hp.embedding_dim - 1); } while (bb == aa);
        a[(size_t)idx] = aa;
        b[(size_t)idx] = bb;
      }
    }

    const size_t table_size = (size_t)1u << (uint32_t)total_n_c;
    S.resize((size_t)hp.n_t);
    for (int i = 0; i < hp.n_t; i++) {
      S[(size_t)i].assign(table_size * (size_t)y_dim, 0.0f);
    }
  }

  LUTCache make_cache() const {
    LUTCache c;
    c.j.assign((size_t)hp.n_t, 0);
    c.r_min.assign((size_t)hp.n_t, 0);
    c.u_min.assign((size_t)hp.n_t, 0.0f);
    return c;
  }

  void cache_index(const float* x, LUTCache& cache) const {
    for (int i = 0; i < hp.n_t; i++) {
      int ji = 0;
      float umin = std::numeric_limits<float>::infinity();
      int rmin = 0;
      for (int r = 0; r < hp.n_c; r++) {
        int idx = i*hp.n_c + r;
        float u = x[a[(size_t)idx]] - x[b[(size_t)idx]];
        if (u > 0.0f) ji |= (1 << r);
        if (std::fabs(u) < std::fabs(umin)) { umin = u; rmin = r; }
      }
      cache.j[(size_t)i] = ji;
      cache.r_min[(size_t)i] = rmin;
      cache.u_min[(size_t)i] = umin;
    }
  }

  void cache_pe_index(const float* u /*[n_t*pos_dim]*/, LUTCache& cache) const {
    for (int i = 0; i < hp.n_t; i++) {
      int ji = 0;
      float umin = std::numeric_limits<float>::infinity();
      int rmin = 0;
      for (int r = 0; r < hp.positional_dim; r++) {
        float val = u[i*hp.positional_dim + r];
        if (val > 0.0f) ji |= (1 << r);
        if (std::fabs(val) < std::fabs(umin)) { umin = val; rmin = r; }
      }
      cache.j[(size_t)i] = ji;
      cache.r_min[(size_t)i] = rmin;
      cache.u_min[(size_t)i] = umin;
    }
  }

  void forward(const LUTCache& cache, float* y /*[y_dim]*/) const {
    for (int i = 0; i < hp.n_t; i++) {
      size_t base = (size_t)cache.j[(size_t)i] * (size_t)y_dim;
      const auto& tab = S[(size_t)i];
      for (int k = 0; k < y_dim; k++) y[k] += tab[base + (size_t)k];
    }
  }

  void backward(const LUTCache& cache,
                float* x_grad /*[embedding_dim]*/,
                const float* y_grad /*[y_dim]*/,
                float lr) {
    for (int i = 0; i < hp.n_t; i++) {
      int j = cache.j[(size_t)i];
      int rmin = cache.r_min[(size_t)i];
      float umin = cache.u_min[(size_t)i];

      int jbar = (j ^ (1 << rmin));

      size_t base  = (size_t)j    * (size_t)y_dim;
      size_t baseb = (size_t)jbar * (size_t)y_dim;

      auto& tab = S[(size_t)i];

      float gi = 0.0f;
      for (int k = 0; k < y_dim; k++) {
        gi += y_grad[k] * (tab[baseb + (size_t)k] - tab[base + (size_t)k]);
      }
      float v = gi * Up(umin);

      int idx = i*hp.n_c + rmin;
      x_grad[a[(size_t)idx]] += v;
      x_grad[b[(size_t)idx]] -= v;

      for (int k = 0; k < y_dim; k++) tab[base + (size_t)k] -= lr * y_grad[k];
    }
  }
};

inline size_t concat_index(const HyperParams& hp, int Q, int K, int PE, int y_dim) {
  int shiftQ = hp.n_c + hp.positional_dim;
  int shiftK = hp.positional_dim;
  uint32_t j = ((uint32_t)Q << shiftQ) | ((uint32_t)K << shiftK) | (uint32_t)PE;
  return (size_t)j * (size_t)y_dim;
}
