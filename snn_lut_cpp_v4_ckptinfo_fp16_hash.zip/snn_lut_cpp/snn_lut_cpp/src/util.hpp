#pragma once
#include <string>
#include <vector>
#include <filesystem>
#include <fstream>
#include <algorithm>
#include <stdexcept>

namespace fs = std::filesystem;

inline void ensure_dir(const std::string& dir) {
  fs::create_directories(fs::path(dir));
}

inline void append_line(const std::string& path, const std::string& line) {
  std::ofstream f(path, std::ios::app);
  if (!f) throw std::runtime_error("Failed to append to: " + path);
  f << line << "\n";
}

inline std::vector<fs::directory_entry> list_ckpts_sorted(const std::string& dir, const std::string& prefix) {
  std::vector<fs::directory_entry> out;
  for (auto& e : fs::directory_iterator(fs::path(dir))) {
    if (!e.is_regular_file()) continue;
    auto name = e.path().filename().string();
    if (name.rfind(prefix, 0) == 0) out.push_back(e);
  }
  std::sort(out.begin(), out.end(), [](auto& a, auto& b){
    return a.path().filename().string() < b.path().filename().string();
  });
  return out;
}

inline void prune_old_ckpts(const std::string& dir, const std::string& prefix, int keep_last) {
  if (keep_last <= 0) return;
  auto v = list_ckpts_sorted(dir, prefix);
  if ((int)v.size() <= keep_last) return;
  int to_delete = (int)v.size() - keep_last;
  for (int i=0;i<to_delete;i++) {
    std::error_code ec;
    fs::remove(v[(size_t)i].path(), ec);
  }
}
