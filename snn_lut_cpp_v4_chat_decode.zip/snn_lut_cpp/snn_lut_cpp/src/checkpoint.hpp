#pragma once
#include "config.hpp"
#include "rng.hpp"
#include "dataset.hpp"
#include "model.hpp"
#include "io.hpp"
#include <string>
#include <fstream>
#include <stdexcept>
#include <cstdint>
#include <cstring>

struct Checkpoint {
  static constexpr uint64_t MAGIC = 0x54554C4E4E535F53ull; // "S_SNNLUT"-ish

  // Legacy HyperParams layout (ckpt_version == 1). This must match the exact
  // struct written by older checkpoints (raw struct bytes).
  struct HyperParamsV1 {
    int vocab_size = 256;
    int context    = 32;
    int embedding_dim  = 32;
    int positional_dim = 4;
    int num_layers     = 6;
    int num_heads      = 4;
    int n_t = 16;
    int n_c = 6;
    int testing_length = 10000;
    float temp_train   = 1.0f;
    float temp_sample  = 0.4f;
    uint32_t ckpt_version = 1;
    bool use_markers = false;
  };

  // Fast content hash for integrity checks (FNV-1a 64-bit)
  static uint64_t fnv1a64(const uint8_t* data, size_t n) {
    uint64_t h = 1469598103934665603ull;
    for (size_t i = 0; i < n; i++) { h ^= (uint64_t)data[i]; h *= 1099511628211ull; }
    return h;
  }

  // IEEE 754 half conversions (no dependencies)
  static uint16_t f32_to_f16(float f) {
    uint32_t x; std::memcpy(&x, &f, sizeof(x));
    uint32_t sign = (x >> 31) & 1;
    uint32_t exp  = (x >> 23) & 0xFF;
    uint32_t mant = x & 0x7FFFFF;

    uint16_t hs = (uint16_t)(sign << 15);
    if (exp == 255) { // inf/nan
      uint16_t hm = (mant ? 0x200 : 0);
      return (uint16_t)(hs | 0x7C00 | hm);
    }
    int32_t e = (int32_t)exp - 127 + 15;
    if (e >= 31) return (uint16_t)(hs | 0x7C00);
    if (e <= 0) {
      if (e < -10) return hs;
      mant |= 0x800000;
      int32_t shift = 14 - e;
      uint16_t hm = (uint16_t)(mant >> shift);
      if ((mant >> (shift-1)) & 1) hm++;
      return (uint16_t)(hs | hm);
    }
    uint16_t he = (uint16_t)(e << 10);
    uint16_t hm = (uint16_t)(mant >> 13);
    if (mant & 0x1000) hm++;
    return (uint16_t)(hs | he | (hm & 0x3FF));
  }

  static float f16_to_f32(uint16_t h) {
    uint32_t sign = (h >> 15) & 1;
    uint32_t exp  = (h >> 10) & 0x1F;
    uint32_t mant = h & 0x3FF;

    uint32_t out_sign = sign << 31;
    uint32_t out_exp, out_mant;

    if (exp == 0) {
      if (mant == 0) { uint32_t z = out_sign; float f; std::memcpy(&f, &z, 4); return f; }
      exp = 1;
      while ((mant & 0x400) == 0) { mant <<= 1; exp--; }
      mant &= 0x3FF;
      out_exp = (exp - 1 + 127 - 15) << 23;
      out_mant = mant << 13;
    } else if (exp == 31) {
      out_exp = 255 << 23;
      out_mant = mant ? (mant << 13) : 0;
    } else {
      out_exp = (exp + 127 - 15) << 23;
      out_mant = mant << 13;
    }
    uint32_t z = out_sign | out_exp | out_mant;
    float f; std::memcpy(&f, &z, 4); return f;
  }

  static void write_float_vec(std::ofstream& f, const std::vector<float>& v, bool fp16) {
    uint64_t n = (uint64_t)v.size();
    f.write((const char*)&n, sizeof(n));
    uint8_t mode = fp16 ? 1 : 0;
    f.write((const char*)&mode, sizeof(mode));
    if (!n) return;
    if (!fp16) {
      f.write((const char*)v.data(), (std::streamsize)(n * sizeof(float)));
    } else {
      std::vector<uint16_t> h((size_t)n);
      for (size_t i = 0; i < (size_t)n; i++) h[i] = f32_to_f16(v[i]);
      f.write((const char*)h.data(), (std::streamsize)(n * sizeof(uint16_t)));
    }
  }

  static void read_float_vec(std::ifstream& f, std::vector<float>& v) {
    uint64_t n=0; f.read((char*)&n, sizeof(n));
    uint8_t mode=0; f.read((char*)&mode, sizeof(mode));
    v.resize((size_t)n);
    if (!n) return;
    if (mode == 0) {
      f.read((char*)v.data(), (std::streamsize)(n * sizeof(float)));
    } else {
      std::vector<uint16_t> h((size_t)n);
      f.read((char*)h.data(), (std::streamsize)(n * sizeof(uint16_t)));
      for (size_t i = 0; i < (size_t)n; i++) v[i] = f16_to_f32(h[i]);
    }
  }

  // Legacy float vector format (ckpt_version == 1): [u64 n][float * n]
  // (no mode byte).
  static void read_float_vec_legacy_fp32(std::ifstream& f, std::vector<float>& v) {
    uint64_t n=0;
    f.read((char*)&n, sizeof(n));
    v.resize((size_t)n);
    if (!n) return;
    f.read((char*)v.data(), (std::streamsize)(n * sizeof(float)));
  }

  template<typename T>
  static void write_vec(std::ofstream& f, const std::vector<T>& v) {
    uint64_t n = (uint64_t)v.size();
    f.write((const char*)&n, sizeof(n));
    if (n) f.write((const char*)v.data(), (std::streamsize)(n * sizeof(T)));
  }

  template<typename T>
  static void read_vec(std::ifstream& f, std::vector<T>& v) {
    uint64_t n=0;
    f.read((char*)&n, sizeof(n));
    v.resize((size_t)n);
    if (n) f.read((char*)v.data(), (std::streamsize)(n * sizeof(T)));
  }

  static void save(const std::string& path,
                   const HyperParams& hp,
                   uint64_t step,
                   const RNG& rng,
                   const MultiDataset& data,
                   const Model& model) {
    std::ofstream f(path, std::ios::binary);
    if (!f) throw std::runtime_error("Failed to write checkpoint: " + path);

    uint64_t magic = MAGIC;
    f.write((const char*)&magic, sizeof(magic));
    uint32_t ver = hp.ckpt_version;
    f.write((const char*)&ver, sizeof(ver));

    f.write((const char*)&hp, sizeof(HyperParams));
    f.write((const char*)&step, sizeof(step));
    f.write((const char*)&rng.s, sizeof(rng.s));

    uint64_t nf = (uint64_t)data.files.size();
    f.write((const char*)&nf, sizeof(nf));
    for (auto& df : data.files) {
      uint64_t plen = (uint64_t)df.path.size();
      f.write((const char*)&plen, sizeof(plen));
      f.write(df.path.data(), (std::streamsize)plen);

      f.write((const char*)&df.usable_len, sizeof(df.usable_len));
      write_vec(f, df.reserved);
      write_vec(f, df.val_idx);

      uint64_t data_hash = fnv1a64(df.data.data(), df.data.size());
      f.write((const char*)&data_hash, sizeof(data_hash));
    }

    write_float_vec(f, model.token_embedder, hp.ckpt_fp16);
    write_float_vec(f, model.z, hp.ckpt_fp16);
    write_vec(f, model.tokens);
    write_float_vec(f, model.output, hp.ckpt_fp16);

    auto write_lut = [&](const LUT& lut) {
      f.write((const char*)&lut.total_n_c, sizeof(lut.total_n_c));
      f.write((const char*)&lut.y_dim, sizeof(lut.y_dim));
      write_vec(f, lut.a);
      write_vec(f, lut.b);
      uint64_t nt = (uint64_t)lut.S.size();
      f.write((const char*)&nt, sizeof(nt));
      for (auto& tab : lut.S) write_float_vec(f, tab, hp.ckpt_fp16);
    };

    uint64_t L = (uint64_t)model.ffn.size();
    f.write((const char*)&L, sizeof(L));
    for (auto& lut : model.ffn) write_lut(lut);

    write_lut(model.unembed);

    uint64_t nlayer = (uint64_t)model.heads.size();
    f.write((const char*)&nlayer, sizeof(nlayer));
    for (auto& layer : model.heads) {
      uint64_t nh = (uint64_t)layer.size();
      f.write((const char*)&nh, sizeof(nh));
      for (auto& h : layer) {
        write_float_vec(f, h.positional, hp.ckpt_fp16);
        write_lut(h.V);
      }
    }
  }

  static void load(const std::string& path,
                   HyperParams& hp,
                   uint64_t& step,
                   RNG& rng,
                   MultiDataset& data,
                   Model& model) {
    std::ifstream f(path, std::ios::binary);
    if (!f) throw std::runtime_error("Failed to read checkpoint: " + path);

    uint64_t magic=0;
    f.read((char*)&magic, sizeof(magic));
    if (magic != MAGIC) throw std::runtime_error("Bad checkpoint magic");

    uint32_t ver=0;
    f.read((char*)&ver, sizeof(ver));

    // ---- Legacy loader (ckpt_version == 1) ----
    if (ver == 1) {
      HyperParamsV1 hp1;
      f.read((char*)&hp1, sizeof(HyperParamsV1));
      f.read((char*)&step, sizeof(step));
      f.read((char*)&rng.s, sizeof(rng.s));

      // Map legacy fields into current HyperParams
      hp.vocab_size      = hp1.vocab_size;
      hp.context         = hp1.context;
      hp.embedding_dim   = hp1.embedding_dim;
      hp.positional_dim  = hp1.positional_dim;
      hp.num_layers      = hp1.num_layers;
      hp.num_heads       = hp1.num_heads;
      hp.n_t             = hp1.n_t;
      hp.n_c             = hp1.n_c;
      hp.testing_length  = hp1.testing_length;
      hp.temp_train      = hp1.temp_train;
      hp.temp_sample     = hp1.temp_sample;
      hp.use_markers     = hp1.use_markers;
      // New fields
      hp.ckpt_version    = 2;
      hp.ckpt_fp16       = true;

      data.hp = hp;
      data.files.clear();
      uint64_t nf=0;
      f.read((char*)&nf, sizeof(nf));
      data.files.resize((size_t)nf);

      for (uint64_t i = 0; i < nf; i++) {
        uint64_t plen=0;
        f.read((char*)&plen, sizeof(plen));
        data.files[(size_t)i].path.resize((size_t)plen);
        f.read(&data.files[(size_t)i].path[0], (std::streamsize)plen);

        f.read((char*)&data.files[(size_t)i].usable_len, sizeof(uint32_t));
        read_vec(f, data.files[(size_t)i].reserved);
        read_vec(f, data.files[(size_t)i].val_idx);

        auto raw = read_all_bytes(data.files[(size_t)i].path);
        data.files[(size_t)i].data = apply_modality_markers(hp, data.files[(size_t)i].path, raw);
        uint32_t expected = (uint32_t)(data.files[(size_t)i].data.size() - (size_t)(hp.context + 1));
        if (expected != data.files[(size_t)i].usable_len) {
          throw std::runtime_error("Dataset file changed size since checkpoint: " + data.files[(size_t)i].path);
        }
      }

      model.init(hp, rng);

      // Model tensors (legacy FP32 vec format)
      read_float_vec_legacy_fp32(f, model.token_embedder);
      read_float_vec_legacy_fp32(f, model.z);
      read_vec(f, model.tokens);
      read_float_vec_legacy_fp32(f, model.output);

      auto read_lut_legacy = [&](LUT& lut) {
        f.read((char*)&lut.total_n_c, sizeof(lut.total_n_c));
        f.read((char*)&lut.y_dim, sizeof(lut.y_dim));
        lut.hp = hp;
        read_vec(f, lut.a);
        read_vec(f, lut.b);
        uint64_t nt=0;
        f.read((char*)&nt, sizeof(nt));
        lut.S.resize((size_t)nt);
        for (auto& tab : lut.S) read_float_vec_legacy_fp32(f, tab);
      };

      uint64_t L=0;
      f.read((char*)&L, sizeof(L));
      model.ffn.resize((size_t)L);
      model.ffn_cache.resize((size_t)L);
      for (size_t i = 0; i < (size_t)L; i++) {
        read_lut_legacy(model.ffn[i]);
        model.ffn_cache[i].resize((size_t)hp.context);
        for (int pos = 0; pos < hp.context; pos++) model.ffn_cache[i][(size_t)pos] = model.ffn[i].make_cache();
      }

      read_lut_legacy(model.unembed);
      model.unembed_cache.resize((size_t)hp.context);
      for (int pos=0; pos<hp.context; pos++) model.unembed_cache[(size_t)pos] = model.unembed.make_cache();

      uint64_t nlayer=0;
      f.read((char*)&nlayer, sizeof(nlayer));
      model.heads.resize((size_t)nlayer);
      for (size_t l=0; l<(size_t)nlayer; l++) {
        uint64_t nh=0;
        f.read((char*)&nh, sizeof(nh));
        model.heads[l].resize((size_t)nh);
        for (size_t h=0; h<(size_t)nh; h++) {
          model.heads[l][h].hp = hp;
          read_float_vec_legacy_fp32(f, model.heads[l][h].positional);
          read_lut_legacy(model.heads[l][h].V);
          model.heads[l][h].V_cache.resize((size_t)hp.context);
          model.heads[l][h].PE_cache.resize((size_t)hp.context);
          for (int pos=0; pos<hp.context; pos++) {
            model.heads[l][h].V_cache[(size_t)pos]  = model.heads[l][h].V.make_cache();
            model.heads[l][h].PE_cache[(size_t)pos] = model.heads[l][h].V.make_cache();
          }
        }
      }
      return;
    }

    f.read((char*)&hp, sizeof(HyperParams));
    f.read((char*)&step, sizeof(step));
    f.read((char*)&rng.s, sizeof(rng.s));

    data.hp = hp;
    data.files.clear();
    uint64_t nf=0;
    f.read((char*)&nf, sizeof(nf));
    data.files.resize((size_t)nf);

    for (uint64_t i = 0; i < nf; i++) {
      uint64_t plen=0;
      f.read((char*)&plen, sizeof(plen));
      data.files[(size_t)i].path.resize((size_t)plen);
      f.read(&data.files[(size_t)i].path[0], (std::streamsize)plen);

      f.read((char*)&data.files[(size_t)i].usable_len, sizeof(uint32_t));
      read_vec(f, data.files[(size_t)i].reserved);
      read_vec(f, data.files[(size_t)i].val_idx);

      uint64_t data_hash_saved = 0;
      f.read((char*)&data_hash_saved, sizeof(data_hash_saved));

      auto raw = read_all_bytes(data.files[(size_t)i].path);
      data.files[(size_t)i].data = apply_modality_markers(hp, data.files[(size_t)i].path, raw);

      uint32_t expected = (uint32_t)(data.files[(size_t)i].data.size() - (size_t)(hp.context + 1));
      if (expected != data.files[(size_t)i].usable_len) {
        throw std::runtime_error("Dataset file changed size since checkpoint: " + data.files[(size_t)i].path);
      }
      uint64_t data_hash_now = fnv1a64(data.files[(size_t)i].data.data(), data.files[(size_t)i].data.size());
      if (data_hash_now != data_hash_saved) {
        throw std::runtime_error("Dataset file content changed since checkpoint (hash mismatch): " + data.files[(size_t)i].path);
      }
    }

    model.init(hp, rng);

    read_float_vec(f, model.token_embedder);
    read_float_vec(f, model.z);
    read_vec(f, model.tokens);
    read_float_vec(f, model.output);

    auto read_lut = [&](LUT& lut) {
      f.read((char*)&lut.total_n_c, sizeof(lut.total_n_c));
      f.read((char*)&lut.y_dim, sizeof(lut.y_dim));
      lut.hp = hp;
      read_vec(f, lut.a);
      read_vec(f, lut.b);
      uint64_t nt=0;
      f.read((char*)&nt, sizeof(nt));
      lut.S.resize((size_t)nt);
      for (auto& tab : lut.S) read_float_vec(f, tab);
    };

    uint64_t L=0;
    f.read((char*)&L, sizeof(L));
    model.ffn.resize((size_t)L);
    model.ffn_cache.resize((size_t)L);
    for (size_t i = 0; i < (size_t)L; i++) {
      read_lut(model.ffn[i]);
      model.ffn_cache[i].resize((size_t)hp.context);
      for (int pos = 0; pos < hp.context; pos++) model.ffn_cache[i][(size_t)pos] = model.ffn[i].make_cache();
    }

    read_lut(model.unembed);
    model.unembed_cache.resize((size_t)hp.context);
    for (int pos=0; pos<hp.context; pos++) model.unembed_cache[(size_t)pos] = model.unembed.make_cache();

    uint64_t nlayer=0;
    f.read((char*)&nlayer, sizeof(nlayer));
    model.heads.resize((size_t)nlayer);
    for (size_t l=0; l<(size_t)nlayer; l++) {
      uint64_t nh=0;
      f.read((char*)&nh, sizeof(nh));
      model.heads[l].resize((size_t)nh);
      for (size_t h=0; h<(size_t)nh; h++) {
        model.heads[l][h].hp = hp;
        read_float_vec(f, model.heads[l][h].positional);
        read_lut(model.heads[l][h].V);
        model.heads[l][h].V_cache.resize((size_t)hp.context);
        model.heads[l][h].PE_cache.resize((size_t)hp.context);
        for (int pos=0; pos<hp.context; pos++) {
          model.heads[l][h].V_cache[(size_t)pos]  = model.heads[l][h].V.make_cache();
          model.heads[l][h].PE_cache[(size_t)pos] = model.heads[l][h].V.make_cache();
        }
      }
    }
  }
};
