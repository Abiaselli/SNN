#include "config.hpp"
#include "rng.hpp"
#include "dataset.hpp"
#include "model.hpp"
#include "checkpoint.hpp"
#include "io.hpp"
#include "util.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <cstring>

static void print_decoded_byte(uint8_t b, const std::string& mode) {
  if (mode == "raw") { std::cout << (char)b; return; }
  if (mode == "text") {
    if (b == 9 || b == 10 || b == 13 || (b >= 32 && b <= 126)) std::cout << (char)b;
    else std::cout << '.';
    return;
  }
  if (mode == "hex") {
    static const char* hexd = "0123456789ABCDEF";
    std::cout << hexd[(b >> 4) & 0xF] << hexd[b & 0xF];
    return;
  }
  // auto (default): printable ASCII, else \xHH escape (safe for byte-level multimodal)
  if (b == 9 || b == 10 || b == 13 || (b >= 32 && b <= 126)) {
    std::cout << (char)b;
  } else {
    static const char* hexd = "0123456789ABCDEF";
    std::cout << "\\x" << hexd[(b >> 4) & 0xF] << hexd[b & 0xF];
  }
}
#include <cmath>

static std::string get_arg(int& i, int argc, char** argv) {
  if (i+1 >= argc) throw std::runtime_error(std::string("Missing value for ") + argv[i]);
  return argv[++i];
}

static double eval_nll(Model& model, const MultiDataset& data, int per_file_samples = 200) {
  double total = 0.0;
  uint64_t count = 0;
  for (auto& f : data.files) {
    int n = std::min((int)f.val_idx.size(), per_file_samples);
    for (int i = 0; i < n; i++) {
      uint32_t idx = f.val_idx[(size_t)i];
      model.load_snippet(f.data.data(), idx);
      model.forward();
      float* outp = &model.output[(size_t)(model.hp.context-1) * (size_t)model.hp.vocab_size];
      softmax_inplace(outp, model.hp.vocab_size, 1.0f);
      int target = model.tokens[(size_t)model.hp.context];
      float p = outp[(size_t)target];
      total += -std::log((double)std::max(p, 1e-20f));
      count++;
    }
  }
  return total / (double)std::max<uint64_t>(1, count);
}

int main(int argc, char** argv) {
  try {
    if (argc < 2) {
      std::cerr << "Usage:\n"
                << "  snn_lut train  --data file1 --data file2 ... --ckpt-dir runs/run1 [--resume ckpt.bin] [--steps N]\n"
                << "               [--save-every K] [--eval-every E] [--log-every L] [--keep-last M] [--seed S]\n"
                << "               [--context C --emb D --layers L --heads H --nt NT --nc NC] [--markers] [--ckpt-fp16|--ckpt-fp32]\n"
                << "  snn_lut sample --ckpt ckpt.bin --prompt \"...\" --len N [--temp T] [--decode auto|text|hex|raw] [--out out.bin]\n"
                << "  snn_lut chat   --ckpt ckpt.bin [--prompt \"...\"] --len N [--temp T] [--decode auto|text|hex|raw]\n"
                << "  snn_lut eval   --ckpt ckpt.bin\n"
                << "  snn_lut ckpt-info --ckpt ckpt.bin\n"
                << "  snn_lut ckpt-convert --ckpt IN.bin --out OUT.bin [--ckpt-fp16|--ckpt-fp32]\n";
      return 1;
    }

    std::string cmd = argv[1];
    HyperParams hp;
    uint64_t seed = 0xC0FFEEull;
    uint64_t steps = 1000;
    uint64_t save_every = 1000;
    uint64_t eval_every = 2000;
    uint64_t log_every  = 200;
    int keep_last = 5;

    std::string ckpt_dir;
    std::string resume_ckpt;
    std::string ckpt_path;

    std::vector<std::string> data_files;

    std::string prompt;
    int sample_len = 200;
    float temp = hp.temp_sample;
    std::string sample_out;
    std::string decode_mode = "auto"; // auto|text|hex|raw

    for (int i = 2; i < argc; i++) {
      std::string a = argv[i];
      if (a == "--data") data_files.push_back(get_arg(i, argc, argv));
      else if (a == "--ckpt-dir") ckpt_dir = get_arg(i, argc, argv);
      else if (a == "--ckpt") ckpt_path = get_arg(i, argc, argv);
      else if (a == "--resume") resume_ckpt = get_arg(i, argc, argv);
      else if (a == "--steps") steps = std::stoull(get_arg(i, argc, argv));
      else if (a == "--save-every") save_every = std::stoull(get_arg(i, argc, argv));
      else if (a == "--eval-every") eval_every = std::stoull(get_arg(i, argc, argv));
      else if (a == "--log-every") log_every = std::stoull(get_arg(i, argc, argv));
      else if (a == "--keep-last") keep_last = std::stoi(get_arg(i, argc, argv));
      else if (a == "--seed") seed = std::stoull(get_arg(i, argc, argv));
      else if (a == "--prompt") prompt = get_arg(i, argc, argv);
      else if (a == "--len") sample_len = std::stoi(get_arg(i, argc, argv));
      else if (a == "--temp") temp = std::stof(get_arg(i, argc, argv));
      else if (a == "--out") sample_out = get_arg(i, argc, argv);
      else if (a == "--decode") decode_mode = get_arg(i, argc, argv);

      else if (a == "--context") hp.context = std::stoi(get_arg(i, argc, argv));
      else if (a == "--emb") hp.embedding_dim = std::stoi(get_arg(i, argc, argv));
      else if (a == "--layers") hp.num_layers = std::stoi(get_arg(i, argc, argv));
      else if (a == "--heads") hp.num_heads = std::stoi(get_arg(i, argc, argv));
      else if (a == "--nt") hp.n_t = std::stoi(get_arg(i, argc, argv));
      else if (a == "--nc") hp.n_c = std::stoi(get_arg(i, argc, argv));
      else if (a == "--test") hp.testing_length = std::stoi(get_arg(i, argc, argv));
      else if (a == "--markers") hp.use_markers = true;
      else if (a == "--ckpt-fp16") hp.ckpt_fp16 = true;
      else if (a == "--ckpt-fp32") hp.ckpt_fp16 = false;
      else throw std::runtime_error("Unknown arg: " + a);
    }

    RNG rng(seed);
    MultiDataset data; data.hp = hp;
    Model model;
    uint64_t step0 = 0;

    if (cmd == "train") {
      if (ckpt_dir.empty()) throw std::runtime_error("train requires --ckpt-dir runs/runX");
      ensure_dir(ckpt_dir);
      const std::string loss_csv = (std::filesystem::path(ckpt_dir) / "loss.csv").string();

      if (!resume_ckpt.empty()) {
        // Resume: load model, dataset and RNG state from checkpoint
        Checkpoint::load(resume_ckpt, hp, step0, rng, data, model);
        std::cerr << "Resumed from " << resume_ckpt << " at step=" << step0 << "\n";
        // If additional data files are provided, append them to the existing dataset. This allows
        // continued training on new sources without discarding the original train/val split.
        for (auto& p : data_files) {
          try {
            data.add_file(p, rng);
            std::cerr << "Loaded additional dataset: " << p << "\n";
          } catch (const std::exception& e) {
            std::cerr << "Warning: failed to load additional dataset '" << p << "': " << e.what() << "\n";
          }
        }
      } else {
        // Fresh run: require at least one data file
        if (data_files.empty()) throw std::runtime_error("train requires --data ...");
        for (auto& p : data_files) data.add_file(p, rng);
        model.init(hp, rng);
        step0 = 0;
        // Start a new loss CSV with header
        append_line(loss_csv, "step,train_lr,eval_nll");
      }

      double best_nll = 1e100;
      uint64_t best_step = 0;

      // Baseline evaluation before any new training steps
      double nll0 = eval_nll(model, data, 200);
      std::cerr << "Baseline eval_nll=" << nll0 << " (expected ~5.5 for untrained model)" << "\n";

      for (uint64_t t = 0; t < steps; t++) {
        uint64_t step = step0 + t;
        float lr = learning_rate_schedule(step);

        int fid = data.pick_file(rng);
        uint32_t idx = data.random_train_index(fid, rng);
        model.load_snippet(data.files[(size_t)fid].data.data(), idx);
        model.training_step(lr);

        if (log_every && (t % log_every) == 0) {
          std::cerr << "\rstep=" << step << " lr=" << std::fixed << std::setprecision(6) << lr << "   " << std::flush;
        }

        if (eval_every && (t % eval_every) == 0 && t > 0) {
          double nll = eval_nll(model, data, 100);
          std::cerr << "Sample preview: ";
          if (!data.files.empty() && !data.files[0].val_idx.empty()) {
            uint32_t sidx = data.files[0].val_idx[0];
            std::vector<uint8_t> window((size_t)hp.context, 0);
            for (int p=0;p<hp.context;p++) window[(size_t)p] = data.files[0].data[sidx + (uint32_t)p];
            for (int tprev=0;tprev<120;tprev++) {
              for (int pos=0;pos<hp.context;pos++) {
                int tok = (int)window[(size_t)pos];
                std::memcpy(&model.z[(size_t)pos*(size_t)hp.embedding_dim],
                            &model.token_embedder[(size_t)tok*(size_t)hp.embedding_dim],
                            (size_t)hp.embedding_dim*sizeof(float));
              }
              int nxt = model.infer_next(rng, 0.7f);
              unsigned char c = (unsigned char)nxt;
              if (c==9 || c==10 || c==13 || (c>=32 && c<=126)) std::cerr << (char)c;
              else std::cerr << '.';
              for (int j=0;j<hp.context-1;j++) window[(size_t)j]=window[(size_t)j+1];
              window[(size_t)hp.context-1]=c;
            }
          }
          std::cerr << "\n";
          append_line(loss_csv, std::to_string(step) + "," + std::to_string(lr) + "," + std::to_string(nll));
          std::cerr << "\n eval_nll=" << nll << "\n";

          if (nll < best_nll) {
            best_nll = nll;
            best_step = step;
            std::string best_path = (std::filesystem::path(ckpt_dir) / "best.bin").string();
            Checkpoint::save(best_path, hp, step, rng, data, model);
            std::cerr << "  saved best -> " << best_path << " (step=" << best_step << ")\n";
          }
        }

        if (save_every && (t % save_every) == 0 && t > 0) {
          // rotated checkpoint
          std::ostringstream oss;
          oss << "ckpt_step_" << std::setw(12) << std::setfill('0') << step << ".bin";
          std::string out_path = (std::filesystem::path(ckpt_dir) / oss.str()).string();
          Checkpoint::save(out_path, hp, step, rng, data, model);
          prune_old_ckpts(ckpt_dir, "ckpt_step_", keep_last);
          std::cerr << "\nSaved checkpoint: " << out_path << "\n";
        }
      }

      uint64_t final_step = step0 + steps;
      std::string final_path = (std::filesystem::path(ckpt_dir) / "latest.bin").string();
      Checkpoint::save(final_path, hp, final_step, rng, data, model);
      std::cerr << "\nSaved latest checkpoint: " << final_path << " step=" << final_step << "\n";
      // Compute and report final evaluation NLL over the validation split
      double nll_final = eval_nll(model, data, 200);
      std::cerr << "Final eval_nll=" << nll_final << "\n";
      // Append final evaluation to loss CSV as well
      append_line(loss_csv, std::to_string(final_step) + "," + std::to_string(learning_rate_schedule(final_step)) + "," + std::to_string(nll_final));
      return 0;
    }

    if (cmd == "sample") {
      if (ckpt_path.empty()) throw std::runtime_error("sample requires --ckpt in.bin");
      HyperParams hp2;
      MultiDataset data2;
      Model model2;
      uint64_t step=0;
      RNG rng2(seed);
      Checkpoint::load(ckpt_path, hp2, step, rng2, data2, model2);

      if (prompt.empty()) prompt = "hello";
      std::vector<uint8_t> window((size_t)hp2.context, 0);
      for (int i = 0; i < hp2.context; i++) {
        window[(size_t)i] = (i < (int)prompt.size()) ? (uint8_t)prompt[(size_t)i] : (uint8_t)' ';
      }

      std::vector<uint8_t> out_bytes;
      out_bytes.reserve((size_t)sample_len);

      std::cout << prompt;

      for (int i = 0; i < sample_len; i++) {
        for (int pos = 0; pos < hp2.context; pos++) {
          int tok = (int)window[(size_t)pos];
          std::memcpy(&model2.z[(size_t)pos*(size_t)hp2.embedding_dim],
                      &model2.token_embedder[(size_t)tok*(size_t)hp2.embedding_dim],
                      (size_t)hp2.embedding_dim*sizeof(float));
        }

        int nxt = model2.infer_next(rng2, temp);
        uint8_t b = (uint8_t)nxt;
        out_bytes.push_back(b);

        print_decoded_byte(b, decode_mode);
        std::cout << std::flush;

        for (int j = 0; j < hp2.context-1; j++) window[(size_t)j] = window[(size_t)j+1];
        window[(size_t)hp2.context-1] = b;
      }
      std::cout << "\n";

      if (!sample_out.empty()) {
        write_all_bytes(sample_out, out_bytes);
        std::cerr << "Wrote sampled bytes to: " << sample_out << "\n";
      }
      return 0;
    }

    if (cmd == "chat") {
      if (ckpt_path.empty()) throw std::runtime_error("chat requires --ckpt in.bin");
      HyperParams hp2;
      MultiDataset data2;
      Model model2;
      uint64_t step=0;
      RNG rng2(seed);
      Checkpoint::load(ckpt_path, hp2, step, rng2, data2, model2);

      std::cerr << "Chat mode. Type /exit to quit.\n";
      std::cerr << "Options: --len N (response bytes), --temp T, --decode auto|text|hex|raw\n";

      std::vector<uint8_t> window((size_t)hp2.context, (uint8_t)' ');
      if (!prompt.empty()) {
        for (int i = 0; i < hp2.context; i++) {
          window[(size_t)i] = (i < (int)prompt.size()) ? (uint8_t)prompt[(size_t)i] : (uint8_t)' ';
        }
        std::cout << prompt << "\n";
      }

      std::string line;
      while (true) {
        std::cout << "> " << std::flush;
        if (!std::getline(std::cin, line)) break;
        if (line == "/exit" || line == "/quit") break;

        // push user line bytes + newline into context window
        for (char c : line) {
          uint8_t b = (uint8_t)c;
          for (int j = 0; j < hp2.context-1; j++) window[(size_t)j] = window[(size_t)j+1];
          window[(size_t)hp2.context-1] = b;
        }
        {
          uint8_t b = (uint8_t)'\n';
          for (int j = 0; j < hp2.context-1; j++) window[(size_t)j] = window[(size_t)j+1];
          window[(size_t)hp2.context-1] = b;
        }

        // generate response bytes
        for (int i = 0; i < sample_len; i++) {
          for (int pos = 0; pos < hp2.context; pos++) {
            int tok = (int)window[(size_t)pos];
            std::memcpy(&model2.z[(size_t)pos*(size_t)hp2.embedding_dim],
                        &model2.token_embedder[(size_t)tok*(size_t)hp2.embedding_dim],
                        (size_t)hp2.embedding_dim*sizeof(float));
          }
          int nxt = model2.infer_next(rng2, temp);
          uint8_t b = (uint8_t)nxt;
          print_decoded_byte(b, decode_mode);
          std::cout << std::flush;
          for (int j = 0; j < hp2.context-1; j++) window[(size_t)j] = window[(size_t)j+1];
          window[(size_t)hp2.context-1] = b;
        }
        std::cout << "\n";
      }
      return 0;
    }

    
    if (cmd == "ckpt-info") {
      if (ckpt_path.empty()) throw std::runtime_error("ckpt-info requires --ckpt in.bin");
      HyperParams hp2;
      MultiDataset data2;
      Model model2;
      uint64_t step=0;
      RNG rng2(seed);
      Checkpoint::load(ckpt_path, hp2, step, rng2, data2, model2);

      std::cout << "Checkpoint: " << ckpt_path << "\n";
      std::cout << "step=" << step << "\n";
      std::cout << "context=" << hp2.context << " emb=" << hp2.embedding_dim
                << " layers=" << hp2.num_layers << " heads=" << hp2.num_heads
                << " n_t=" << hp2.n_t << " n_c=" << hp2.n_c << "\n";
      std::cout << "use_markers=" << (hp2.use_markers ? "true" : "false")
                << " ckpt_fp16=" << (hp2.ckpt_fp16 ? "true" : "false") << "\n";

      std::cout << "Dataset files (" << data2.files.size() << "):\n";
      for (auto& f : data2.files) {
        std::cout << "  - " << f.path << " bytes_loaded=" << f.data.size()
                  << " usable_len=" << f.usable_len << "\n";
      }

      std::cout << "Note: checkpoint file size is dominated by LUT tables (V/FFN/unembed), not by the dataset.\n";
      std::cout << "Tip: reduce size by lowering --nt/--nc/--emb/--layers/--heads, or enable --ckpt-fp16.\n";
      return 0;
    }

    if (cmd == "ckpt-convert") {
      if (ckpt_path.empty()) throw std::runtime_error("ckpt-convert requires --ckpt IN.bin");
      if (sample_out.empty()) throw std::runtime_error("ckpt-convert requires --out OUT.bin");

      HyperParams hp2;
      MultiDataset data2;
      Model model2;
      uint64_t step2=0;
      RNG rng2(seed);
      Checkpoint::load(ckpt_path, hp2, step2, rng2, data2, model2);

      // Save in the current checkpoint format. By default we store tensors as FP16 on disk.
      Checkpoint::save(sample_out, hp2, step2, rng2, data2, model2);
      std::cerr << "Wrote converted checkpoint: " << sample_out << "\n";
      return 0;
    }

if (cmd == "eval") {
      if (ckpt_path.empty()) throw std::runtime_error("eval requires --ckpt in.bin");
      HyperParams hp2;
      MultiDataset data2;
      Model model2;
      uint64_t step=0;
      RNG rng2(seed);
      Checkpoint::load(ckpt_path, hp2, step, rng2, data2, model2);
      double nll = eval_nll(model2, data2, 200);
      std::cout << "eval_nll=" << nll << "\n";
      return 0;
    }

    throw std::runtime_error("Unknown command: " + cmd);

  } catch (const std::exception& e) {
    std::cerr << "\nError: " << e.what() << "\n";
    return 1;
  }
}
