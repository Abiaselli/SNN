#pragma once
#include "config.hpp"
#include "rng.hpp"
#include "io.hpp"
#include <vector>
#include <string>
#include <stdexcept>
#include <cstdint>
#include <algorithm>
#include <cctype>

struct DatasetFile {
  std::string path;
  std::vector<uint8_t> data;      // raw bytes
  std::vector<uint8_t> reserved;  // 0/1 mask for training positions
  std::vector<uint32_t> val_idx;  // validation start indices
  uint32_t usable_len = 0;        // data_len - (context+1)
};

struct MultiDataset {
  std::vector<DatasetFile> files;
  HyperParams hp;

  void add_file(const std::string& path, RNG& rng) {
    DatasetFile df;
    df.path = path;
    df.data = read_all_bytes(path);
    // Insert modality markers based on file extension. Treat all files as
    // byte streams but prefix/suffix with textual tags to help the model
    // differentiate modalities. For example, JSON files are wrapped with
    // "<JSON>" ... "</JSON>", text files with "<TXT>" ... "</TXT>", and
    // unknown/binary files with "<BIN>" ... "</BIN>". The markers are ASCII
    // strings converted to bytes.
    {
      // derive uppercase extension without leading dot
      auto pos = path.find_last_of('.');
      std::string ext = (pos == std::string::npos) ? "" : path.substr(pos + 1);
      for (auto& c : ext) c = (char)std::toupper((unsigned char)c);
      std::string type;
      if (ext == "JSON") type = "JSON";
      else if (ext == "TXT" || ext == "TEXT") type = "TXT";
      else if (ext == "CSV") type = "CSV";
      else if (ext == "PARQUET" || ext == "PQ") type = "PARQUET";
      else type = "BIN";
      std::string prefix = "<" + type + ">";
      std::string suffix = "</" + type + ">";
      // build processed data vector with markers
      std::vector<uint8_t> processed;
      processed.reserve(prefix.size() + df.data.size() + suffix.size());
      for (char c : prefix) processed.push_back((uint8_t)c);
      processed.insert(processed.end(), df.data.begin(), df.data.end());
      for (char c : suffix) processed.push_back((uint8_t)c);
      df.data = std::move(processed);
    }
    if (df.data.size() < (size_t)(hp.context + 2)) {
      throw std::runtime_error("File too small for context+1: " + path);
    }
    df.usable_len = (uint32_t)(df.data.size() - (size_t)(hp.context + 1));
    df.reserved.assign(df.usable_len, 0);
    df.val_idx.resize((size_t)hp.testing_length);
    // Reserve validation ranges, ensuring that train and test sequences don't
    // overlap. We sample start indices uniformly and then mark a window of
    // size (2*context) around each index as reserved for validation.
    for (int i = 0; i < hp.testing_length; i++) {
      uint32_t idx = (uint32_t)rng.uniform_int(0, (int)df.usable_len - 1);
      df.val_idx[(size_t)i] = idx;
      int start = std::max(0, (int)idx - hp.context);
      int end   = std::min((int)df.usable_len - 1, (int)idx + hp.context);
      for (int p = start; p <= end; p++) df.reserved[(size_t)p] = 1;
    }
    files.push_back(std::move(df));
  }

  int pick_file(RNG& rng) const {
    uint64_t total = 0;
    for (auto& f : files) total += f.usable_len;
    uint64_t r = rng.next_u64() % (total ? total : 1);
    uint64_t acc = 0;
    for (int i = 0; i < (int)files.size(); i++) {
      acc += files[(size_t)i].usable_len;
      if (r < acc) return i;
    }
    return (int)files.size() - 1;
  }

  uint32_t random_train_index(int file_id, RNG& rng) const {
    auto& f = files[(size_t)file_id];
    while (true) {
      uint32_t idx = (uint32_t)rng.uniform_int(0, (int)f.usable_len - 1);
      if (f.reserved[(size_t)idx] == 0) return idx;
    }
  }
};
