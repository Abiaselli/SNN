#pragma once
#include <vector>
#include <string>
#include <fstream>
#include <stdexcept>
#include <cstdint>

inline std::vector<uint8_t> read_all_bytes(const std::string& path) {
  std::ifstream f(path, std::ios::binary);
  if (!f) throw std::runtime_error("Failed to open file: " + path);
  f.seekg(0, std::ios::end);
  size_t n = (size_t)f.tellg();
  f.seekg(0, std::ios::beg);
  std::vector<uint8_t> buf(n);
  if (n) f.read((char*)buf.data(), (std::streamsize)n);
  return buf;
}

inline void write_all_bytes(const std::string& path, const std::vector<uint8_t>& buf) {
  std::ofstream f(path, std::ios::binary);
  if (!f) throw std::runtime_error("Failed to write file: " + path);
  if (!buf.empty()) f.write((const char*)buf.data(), (std::streamsize)buf.size());
}
